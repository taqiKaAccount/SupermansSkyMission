#include<SDL.h>


void drawObjects(SDL_Renderer* gRnderer, SDL_Texture* assets);
void createObject(int x, int y);

void moveRight();
void moveLeft();
void moveUp();
void moveDown() ;





struct Unit{
SDL_Rect srcRect, moverRect;
};