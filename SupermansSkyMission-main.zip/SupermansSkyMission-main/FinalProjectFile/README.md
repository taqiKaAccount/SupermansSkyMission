Compile by
g++ *.cpp -IC:\mingw_dev_lib\include\SDL2 -IC:\mingw_dev_lib\include\SDL2_ttf -LC:\mingw_dev_lib\lib -w -lmingw32 -lSDL2main -lSDL2 -lSDL2_image -lSDL2_mixer -lSDL2_ttf

Run by
.\a.exe
