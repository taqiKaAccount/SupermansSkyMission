#pragma once
#include "Unit.hpp"


class ObjectCreator{
public:
Unit* getObject(int x, int y);

};


//same as HW4 objectCreator