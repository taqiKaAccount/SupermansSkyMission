#include <SDL.h>
#include <iostream>
#include <string>
#include <SDL_ttf.h>


class ScoreDisplay{
public:





private:
    TTF_Font* font;
    SDL_Texture* textTexture;
    SDL_Rect textRect;

};