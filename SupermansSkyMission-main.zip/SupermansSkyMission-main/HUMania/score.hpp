class Score{
public:
    Score() ;
    //do op overlloading for increments/decrements of 10
    Score& operator++();

    Score& operator--();
    
    int getScore()const;

private:
    int ScoreCount = 0;
}; 