class health{

int life = 3;

public:
int getLife();

void reduceHealth() ; 
};