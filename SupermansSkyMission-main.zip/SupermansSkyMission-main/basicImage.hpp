// #incldue <SDL.h>

// // the basic image creation class, it will be the class from which superman/enemies/obstacles will inherit from

// class basicImage{

// public:

// private:
//     SDL_Renderer *gRenderer;
//     SDL_Texture *assets;
// } ;
